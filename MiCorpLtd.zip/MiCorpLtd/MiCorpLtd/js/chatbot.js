document.addEventListener('DOMContentLoaded', () => {
    const chatbotToggle = document.getElementById('chatbot-toggle');
    const chatbotWindow = document.getElementById('chatbot-window');
    const chatbotClose = document.getElementById('chatbot-close');
    const chatbotMessages = document.getElementById('chatbot-messages');
    const chatbotInput = document.getElementById('chatbot-input');
    const chatbotSend = document.getElementById('chatbot-send');

    if (!chatbotToggle || !chatbotWindow || !chatbotClose || !chatbotMessages || !chatbotInput || !chatbotSend) {
        if (chatbotToggle) chatbotToggle.style.display = 'none';
        return;
    }
    
    let greetingSent = false;
    
    chatbotWindow.classList.remove('active');
    chatbotToggle.setAttribute('aria-expanded', 'false');

    let conversationState = 'initial';
    let collectedData = {};

    const initialMessage = "Hello! I'm the Micorp Bot. How can I assist you today?";
    const initialOptions = [
        { text: "Product Inquiry", value: "product_inquiry" },
        { text: "Chat on WhatsApp", value: "whatsapp" },
        { text: "Leave a Message", value: "leave_message" }
    ];

    function closeChatbot() {
        chatbotWindow.classList.remove('active');
        chatbotToggle.setAttribute('aria-expanded', 'false');
    }

    chatbotToggle.addEventListener('click', () => {
        const isActive = chatbotWindow.classList.toggle('active');
        chatbotToggle.setAttribute('aria-expanded', isActive);
        if (isActive) {
            if (!greetingSent || chatbotMessages.children.length === 0) {
                chatbotMessages.innerHTML = ''; 
                addBotMessage(initialMessage, initialOptions);
                greetingSent = true;
            }
            chatbotInput.focus();
        }
    });
    chatbotClose.addEventListener('click', closeChatbot);

    const sanitizeHTML = (str) => {
        const temp = document.createElement('div');
        temp.textContent = str;
        return temp.innerHTML;
    };

    function addMessage(text, sender, messageOptions = null) {
        const messageDiv = document.createElement('div');
        messageDiv.classList.add('chatbot-message', sender);
        messageDiv.innerHTML = text; 

        if (messageOptions && Array.isArray(messageOptions) && messageOptions.length > 0) {
            const optionsDiv = document.createElement('div');
            optionsDiv.classList.add('chatbot-options');
            messageOptions.forEach(opt => {
                const button = document.createElement('button');
                button.classList.add('chatbot-option-button');
                button.textContent = opt.text;
                button.dataset.value = opt.value;
                button.addEventListener('click', () => handleOptionClick(opt.value, opt.text));
                optionsDiv.appendChild(button);
            });
            messageDiv.appendChild(optionsDiv);
        }
        
        chatbotMessages.appendChild(messageDiv);
        chatbotMessages.scrollTop = chatbotMessages.scrollHeight;
    }

    function addBotMessage(text, messageOptions = null) {
        addMessage(text, 'bot', messageOptions);
    }

    function addUserMessage(text) {
        addMessage(sanitizeHTML(text), 'user');
    }

    function handleOptionClick(value, text) {
        // Hide options after one is clicked
        const optionsContainer = chatbotMessages.querySelector('.chatbot-options');
        if (optionsContainer) {
            optionsContainer.remove();
        }
        addUserMessage(text); 
        processUserInput(value); 
    }
    
    function handleSend() {
        const userText = chatbotInput.value.trim();
        if (userText && conversationState !== 'initial') {
            addUserMessage(userText);
            processUserInput(userText);
            chatbotInput.value = '';
        }
    }

    chatbotSend.addEventListener('click', handleSend);
    chatbotInput.addEventListener('keypress', (e) => {
        if (e.key === 'Enter') {
            handleSend();
        }
    });

    function processUserInput(input) {
        const lowerInput = input.toLowerCase();
        
        switch (conversationState) {
            case 'initial':
                if (lowerInput === 'whatsapp') {
                    addBotMessage("Great! Click the link to start a chat with us on WhatsApp: <a href='https://wa.me/97142390917' target='_blank'>Open WhatsApp</a>.");
                    conversationState = 'finished';
                    setTimeout(resetChatAndOfferRestart, 10000);
                    return;
                } else if (lowerInput === 'product_inquiry' || lowerInput === 'leave_message') {
                    collectedData = { inquiryType: lowerInput === 'product_inquiry' ? 'Product Inquiry' : 'Leave a Message' };
                    addBotMessage("Sure, I can help with that. What's your name?");
                    conversationState = 'ask_name';
                } else {
                    addBotMessage("I'm not sure how to help with that. Please choose one of the options.", initialOptions);
                }
                break;

            case 'ask_name':
                collectedData.name = input; 
                addBotMessage(`Thanks, ${sanitizeHTML(collectedData.name)}. What is your email address?`);
                conversationState = 'ask_email';
                break;

            case 'ask_email':
                if (isValidEmail(input)) {
                    collectedData.email = input;
                    addBotMessage("Great. What is your question or message for our team?");
                    conversationState = 'collect_details';
                } else {
                    addBotMessage("That doesn't look like a valid email. Please enter a correct email address.");
                }
                break;

            case 'collect_details':
                collectedData.details = input;
                let summary = `Thank you, ${sanitizeHTML(collectedData.name)}! I have your information. Our team will review your request and get back to you soon. <br><br>
                               <strong>Summary:</strong> <br>
                               <strong>Inquiry:</strong> ${sanitizeHTML(collectedData.inquiryType)}<br>
                               <strong>Email:</strong> ${sanitizeHTML(collectedData.email)}<br>
                               <strong>Details:</strong> ${sanitizeHTML(collectedData.details)}`; 
                addBotMessage(summary); 
                sendDataToBackend(collectedData); 
                conversationState = 'finished';
                setTimeout(resetChatAndOfferRestart, 10000); 
                break;
            
            case 'finished':
                 addBotMessage("If you have another question, you can start over by typing 'restart'. Otherwise, you can close the chat.");
                break;
        }

        if (lowerInput === 'restart') {
            resetChatAndOfferRestart(false);
        }
    }

    function isValidEmail(email) {
        const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        return emailRegex.test(email);
    }

    async function sendDataToBackend(data) {
        addBotMessage("<i>Submitting your request...</i>");
        const formspreeEndpoint = 'https://formspree.io/f/meokpzlj'; // CHATBOT LEADS ENDPOINT

        const formDataForSpree = new FormData();
        formDataForSpree.append('_subject', `New Chatbot Lead: ${data.inquiryType || 'N/A'}`);
        formDataForSpree.append('Name', data.name || 'N/A');
        formDataForSpree.append('Email', data.email || 'N/A'); 
        formDataForSpree.append('_replyto', data.email || 'N/A'); 
        formDataForSpree.append('Inquiry_Type', data.inquiryType || 'N/A');
        formDataForSpree.append('Details_Message', data.details || 'N/A');
        formDataForSpree.append('_Source_Page', window.location.href);
        formDataForSpree.append('Form_Type', 'Chatbot Lead');

        try {
            const response = await fetch(formspreeEndpoint, {
                method: 'POST',
                body: formDataForSpree,
                headers: {
                    'Accept': 'application/json'
                }
            });

            if (response.ok) {
                // The thank you message is already shown, so we just log success.
                console.log('Chatbot submission successful.');
            } else {
                addBotMessage("Sorry, there was an issue submitting your information. Please try again later or contact us directly via phone or email.");
                console.error('Chatbot submission error to Formspree:', response.status);
            }
        } catch (error) {
            console.error('Network error or other issue sending chatbot data to Formspree:', error);
            addBotMessage("Sorry, we couldn't submit your information due to a network issue. Please check your connection or contact us directly.");
        }
    }

    function resetChatAndOfferRestart(showResetMessage = true) {
        chatbotMessages.innerHTML = ''; 
        conversationState = 'initial';
        collectedData = {};
        greetingSent = false;
        if (showResetMessage) {
            addBotMessage("Chat has been reset. " + initialMessage, initialOptions);
        } else {
            addBotMessage(initialMessage, initialOptions);
        }
        greetingSent = true;
    }
});